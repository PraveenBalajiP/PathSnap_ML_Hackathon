"""
PathSnap preprocessing utilities (shared by notebooks 01-03 and later by the API).

Key design decisions (be ready to explain them in the viva):
  * arc_id is the 0-based ROW INDEX of the .arcs file, so arcs are never dropped
    from the array; degenerate arcs are masked in the spatial index instead.
  * Geometry is computed in UTM zone 32N (EPSG:32632, metres); the data lies at
    ~8.6 E, inside zone 32 (6E-12E). Degrees are never used as distances.
  * .route is a sequence of arcs, not one arc per GPS point, so each point is
    assigned to a route arc with a monotone (order-preserving) dynamic program.
"""
import os
import re
import json
import hashlib
import numpy as np
import pandas as pd
from pyproj import Transformer
from shapely import STRtree, linestrings, points as shp_points

CRS_UTM = "EPSG:32632"
_tf = Transformer.from_crs("EPSG:4326", CRS_UTM, always_xy=True)
EXTS = ["track", "nodes", "arcs", "route"]


# ------------------------------------------------------------- discovery
def discover_trips(root):
    """Find every <trip>.track under `root`. The partition is inferred from the
    folder path ('train' / 'student' / 'eval...'); anything else = 'unassigned'."""
    root = os.path.abspath(root.rstrip("/\\"))
    def part_of(text):
        low = text.lower()
        if "evaluator" in low or re.search(r"(^|[\\/_\-])eval", low):
            return "evaluator_test"
        if "student" in low:
            return "student_test"
        if "train" in low:
            return "train"
        return "unassigned"

    rows = []
    for dp, dn, fn in os.walk(root):
        dn[:] = [d for d in dn if d not in ("__pycache__", ".ipynb_checkpoints", ".git")]
        for f in fn:
            if not f.endswith(".track"):
                continue
            stem = f[:-6]
            rel_root = os.path.relpath(dp, root)                 # path below DATA_ROOT, e.g. train/00000001
            part = part_of(rel_root) if rel_root != "." else "unassigned"
            if part == "unassigned":                             # DATA_ROOT itself may be the 'train' folder
                part = part_of(os.path.basename(root))
            parts = [] if rel_root == "." else rel_root.split(os.sep)
            if not parts or parts[-1] != stem:                   # folder is usually named like the trip: avoid repeating it
                parts.append(stem)
            row = dict(key="__".join(parts), trip=stem, folder=dp, partition=part)
            for e in EXTS:
                p = os.path.join(dp, f"{stem}.{e}")
                row[f"has_{e}"] = os.path.exists(p)
                row[f"kb_{e}"] = round(os.path.getsize(p) / 1024, 1) if os.path.exists(p) else np.nan
            rows.append(row)
    if not rows:
        raise FileNotFoundError(f"No .track files found under {root}")
    return pd.DataFrame(rows).sort_values(["partition", "key"]).reset_index(drop=True)


def load_or_make_splits(trips, work_dir, seed=42, n_train=80, n_student=10, n_eval=10):
    """Used ONLY when the folders do not already tell us the partition.
    Creates a seeded trip-level split (never splits a trip) and stores it in
    work_dir/splits.csv so every notebook uses the identical split."""
    path = os.path.join(work_dir, "splits.csv")
    if os.path.exists(path):
        s = pd.read_csv(path, dtype=str)
        trips = trips.drop(columns="partition").merge(s[["key", "partition"]], on="key", how="left")
        return trips
    keys = trips["key"].sample(frac=1.0, random_state=seed).tolist()
    assign = {}
    for i, k in enumerate(keys):
        assign[k] = "train" if i < n_train else "student_test" if i < n_train + n_student else "evaluator_test"
    trips = trips.copy()
    trips["partition"] = trips["key"].map(assign)
    os.makedirs(work_dir, exist_ok=True)
    trips[["key", "partition"]].to_csv(path, index=False)
    return trips


# --------------------------------------------------------------- loading
def _read(path):
    return pd.read_csv(path, sep=r"\s+", header=None, engine="c").values


def load_trip(folder, trip_id, need_route=True):
    p = lambda ext: os.path.join(folder, f"{trip_id}.{ext}")
    track = _read(p("track")).astype(float)               # lon, lat, t
    nodes = _read(p("nodes")).astype(float)               # lon, lat
    arcs = _read(p("arcs")).astype(np.int64)              # from, to
    route = None
    if need_route and os.path.exists(p("route")) and os.path.getsize(p("route")) > 0:
        route = _read(p("route")).astype(np.int64).ravel()
    return dict(track=track, nodes=nodes, arcs=arcs, route=route)


def file_md5(path):
    h = hashlib.md5()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def project(lonlat):
    x, y = _tf.transform(lonlat[:, 0], lonlat[:, 1])
    return np.column_stack([x, y])


# -------------------------------------------------------------- cleaning
def validate_track(track):
    """Flag (never silently repair) NaN, out-of-range coordinates and
    non-increasing timestamps. Returns (keep_mask, report)."""
    lon, lat, t = track[:, 0], track[:, 1], track[:, 2]
    bad_nan = ~np.isfinite(track).all(axis=1)
    bad_rng = (np.abs(lon) > 180) | (np.abs(lat) > 90)
    dt = np.diff(t, prepend=t[0] - 1)
    bad_time = dt <= 0
    keep = ~(bad_nan | bad_rng | bad_time)
    rep = dict(n=int(len(track)), nan=int(bad_nan.sum()), out_of_range=int(bad_rng.sum()),
               non_increasing_time=int(bad_time.sum()),
               max_gap_s=float(np.max(np.diff(t))) if len(t) > 1 else 0.0)
    return keep, rep


def build_network(nodes_ll, arcs):
    nxy = project(nodes_ll)
    a, b = nxy[arcs[:, 0]], nxy[arcs[:, 1]]
    length = np.hypot(*(b - a).T)
    valid = length > 0.5
    bearing = np.degrees(np.arctan2(b[:, 0] - a[:, 0], b[:, 1] - a[:, 1])) % 360   # 0=N, clockwise
    return dict(nxy=nxy, a=a, b=b, length=length, valid=valid, bearing=bearing, arcs=arcs)


def build_index(net):
    ids = np.flatnonzero(net["valid"])
    geoms = linestrings(np.stack([net["a"][ids], net["b"][ids]], axis=1))
    return STRtree(geoms), ids, geoms


# ------------------------------------------------------ geometry helpers
def seg_dist_frac(p, a, b):
    ab = b - a
    L2 = np.maximum((ab ** 2).sum(1), 1e-9)
    f = np.clip(((p - a) * ab).sum(1) / L2, 0.0, 1.0)
    proj = a + f[:, None] * ab
    return np.hypot(*(p - proj).T), f


def gps_bearing_speed(xy, t):
    n = len(xy)
    nxt, prv = np.minimum(np.arange(n) + 1, n - 1), np.maximum(np.arange(n) - 1, 0)
    d = xy[nxt] - xy[prv]
    dt = np.maximum(t[nxt] - t[prv], 1e-6)
    return np.degrees(np.arctan2(d[:, 0], d[:, 1])) % 360, np.hypot(*d.T) / dt


# ------------------------------------------------- candidate generation
def generate_candidates(xy, t, net, tree, ids, radius=100.0):
    pts = shp_points(xy)
    pi, gi = tree.query(pts, predicate="dwithin", distance=radius)
    arc = ids[gi]
    dist, frac = seg_dist_frac(xy[pi], net["a"][arc], net["b"][arc])
    brg, spd = gps_bearing_speed(xy, t)
    dh = np.abs((brg[pi] - net["bearing"][arc] + 180) % 360 - 180)
    df = pd.DataFrame(dict(pt=pi.astype(np.int32), arc_id=arc.astype(np.int64), dist=dist, frac=frac,
                           arc_len=net["length"][arc], arc_bearing=net["bearing"][arc],
                           gps_bearing=brg[pi], head_diff=dh, speed=spd[pi]))
    return df.sort_values(["pt", "dist"], kind="stable").reset_index(drop=True)


# ----------------------------------------------------------- labelling
def assign_reference_arcs(xy, route, net):
    """Monotone assignment of GPS points to reference route arcs:
        dp[i, j] = d(i, route[j]) + min_{k<=j} dp[i-1, k]
    Returns (label_arc_id, dist_to_label_arc, route_position, plain_nearest_route_arc)."""
    a, b = net["a"][route], net["b"][route]
    n, m = len(xy), len(route)
    D = np.empty((n, m))
    for j in range(m):
        D[:, j], _ = seg_dist_frac(xy, np.broadcast_to(a[j], xy.shape), np.broadcast_to(b[j], xy.shape))
    dp = np.empty((n, m)); bp = np.empty((n, m), dtype=np.int32)
    dp[0] = D[0]
    idx = np.arange(m)
    for i in range(1, n):
        prev = dp[i - 1]
        cm = np.minimum.accumulate(prev)
        is_new = np.r_[True, prev[1:] < cm[:-1]]
        bp[i] = np.maximum.accumulate(np.where(is_new, idx, 0))
        dp[i] = D[i] + cm
    j = int(np.argmin(dp[-1])); path = np.empty(n, dtype=np.int64)
    for i in range(n - 1, -1, -1):
        path[i] = j
        j = bp[i, j]
    return route[path], D[np.arange(n), path], path, route[np.argmin(D, axis=1)]


def label_candidates(cands, label_arc):
    cands["label"] = (cands["arc_id"].values == label_arc[cands["pt"].values]).astype(np.int8)
    return cands


# ----------------------------------------------------------- one trip
def prepare_geometry(folder, tid, need_route=True):
    raw = load_trip(folder, tid, need_route=need_route)
    keep, rep = validate_track(raw["track"])
    track = raw["track"][keep]
    xy, t = project(track[:, :2]), track[:, 2]
    net = build_network(raw["nodes"], raw["arcs"])
    return dict(raw=raw, keep=keep, report=rep, track=track, xy=xy, t=t, net=net)


def process_trip(folder, tid, radius=100.0, with_labels=True):
    g = prepare_geometry(folder, tid, need_route=with_labels)
    tree, ids, _ = build_index(g["net"])
    cands = generate_candidates(g["xy"], g["t"], g["net"], tree, ids, radius)
    out = dict(track=g["track"], xy=g["xy"], t=g["t"], net=g["net"], cands=cands,
               report=g["report"], route=g["raw"]["route"])
    route = g["raw"]["route"]
    if with_labels and route is not None:
        lab, ldist, path, plain = assign_reference_arcs(g["xy"], route, g["net"])
        cands = label_candidates(cands, lab)
        hit = cands.groupby("pt")["label"].max().reindex(range(len(g["xy"])), fill_value=0)
        out.update(cands=cands, label_arc=lab, label_dist=ldist, route_pos=path, plain_nearest=plain,
                   point_has_true_candidate=hit.values.astype(bool))
    return out
