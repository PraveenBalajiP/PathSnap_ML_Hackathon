"""
Feature engineering for (GPS point, candidate arc) pairs.

RULES (leakage prevention):
  * Features never use the label, the reference route, or arc_id / absolute
    coordinates (they would let a model memorise places instead of learning
    the geometry of matching).
  * Everything here is computable at inference time from the GPS track and the
    road network only, so the same code runs in the API.
"""
import numpy as np
import pandas as pd
from preprocess import seg_dist_frac

ID_COLS = ["trip", "pt", "arc_id"]
FEATURES = [
    # --- point-to-arc geometry
    "dist", "dist_gap", "dist_ratio", "dist_rank", "min_dist_pt", "n_cands_pt", "n_within_20m",
    "frac", "along_m", "remain_m", "arc_len",
    # --- direction
    "head_diff", "head_cos",
    # --- temporal context: same arc seen from neighbouring GPS points
    "dist_prev1", "dist_next1", "win_mean5", "win_max5",
    # --- topological consistency with neighbouring nearest arcs
    "follows_prev_nn", "precedes_next_nn", "same_as_nn",
    # --- road structure
    "is_oneway", "from_indeg", "to_outdeg",
    # --- GPS motion
    "speed", "gps_turn", "dt_prev", "dt_next",
]


def _bearing(d):
    return np.degrees(np.arctan2(d[:, 0], d[:, 1])) % 360


def build_features(cands, xy, t, net, trip_key):
    n = len(xy)
    df = cands[["pt", "arc_id", "dist", "frac", "arc_len", "head_diff", "speed"] +
               (["label"] if "label" in cands else [])].copy()
    pt = df["pt"].values.astype(np.int64)
    arc = df["arc_id"].values
    A = net["arcs"]
    nnodes = len(net["nxy"])

    # ---- point-level candidate statistics (cands are sorted by dist within each point)
    g = df.groupby("pt")["dist"]
    df["min_dist_pt"] = g.transform("min")
    df["n_cands_pt"] = g.transform("size")
    df["dist_rank"] = df.groupby("pt").cumcount() + 1
    df["n_within_20m"] = (df["dist"] <= 20).groupby(df["pt"]).transform("sum")
    df["dist_gap"] = df["dist"] - df["min_dist_pt"]
    df["dist_ratio"] = df["dist"] / (df["min_dist_pt"] + 1.0)

    # ---- position along the arc
    df["along_m"] = df["frac"] * df["arc_len"]
    df["remain_m"] = (1 - df["frac"]) * df["arc_len"]
    df["head_cos"] = np.cos(np.radians(df["head_diff"]))

    # ---- temporal context: distance of neighbouring GPS points to THIS arc
    def dist_at(off):
        j = np.clip(pt + off, 0, n - 1)
        d, _ = seg_dist_frac(xy[j], net["a"][arc], net["b"][arc])
        return d
    d_m2, d_m1, d_p1, d_p2 = dist_at(-2), dist_at(-1), dist_at(1), dist_at(2)
    d0 = df["dist"].values
    df["dist_prev1"], df["dist_next1"] = d_m1, d_p1
    stack = np.vstack([d_m2, d_m1, d0, d_p1, d_p2])
    df["win_mean5"], df["win_max5"] = stack.mean(0), stack.max(0)

    # ---- topology: relation to nearest arc of previous/next GPS point
    nn = df.groupby("pt")["arc_id"].first().reindex(range(n)).fillna(-1).astype(np.int64).values
    prev_nn, next_nn = nn[np.clip(pt - 1, 0, n - 1)], nn[np.clip(pt + 1, 0, n - 1)]
    ok_p, ok_n = prev_nn >= 0, next_nn >= 0
    pn, nx = np.where(ok_p, prev_nn, 0), np.where(ok_n, next_nn, 0)
    df["follows_prev_nn"] = (ok_p & ((arc == prev_nn) | (A[pn, 1] == A[arc, 0]))).astype(np.float32)
    df["precedes_next_nn"] = (ok_n & ((arc == next_nn) | (A[arc, 1] == A[nx, 0]))).astype(np.float32)
    df["same_as_nn"] = (arc == nn[pt]).astype(np.float32)

    # ---- road structure
    outdeg = np.bincount(A[:, 0], minlength=nnodes)
    indeg = np.bincount(A[:, 1], minlength=nnodes)
    key = A[:, 0].astype(np.int64) * nnodes + A[:, 1]
    rkey = A[:, 1].astype(np.int64) * nnodes + A[:, 0]
    has_rev = np.isin(rkey, key)
    df["is_oneway"] = (~has_rev[arc]).astype(np.float32)
    df["from_indeg"] = indeg[A[arc, 0]]
    df["to_outdeg"] = outdeg[A[arc, 1]]

    # ---- GPS motion (point-level, then mapped to candidates)
    dprev = np.diff(xy, axis=0, prepend=xy[:1]); dnext = np.diff(xy, axis=0, append=xy[-1:])
    b_prev, b_next = _bearing(dprev), _bearing(dnext)
    turn = np.abs((b_next - b_prev + 180) % 360 - 180)
    df["gps_turn"] = turn[pt]
    dtp = np.diff(t, prepend=t[0]); dtn = np.diff(t, append=t[-1])
    df["dt_prev"], df["dt_next"] = dtp[pt], dtn[pt]

    df.insert(0, "trip", trip_key)
    cols = ID_COLS + FEATURES + (["label"] if "label" in df else [])
    out = df[cols].copy()
    out[FEATURES] = out[FEATURES].astype(np.float32)
    return out
